//    This file is part of Gaumerie (C)2006-2007 ClassPad.fr

//    Gaumerie is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.

//    Gaumerie is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Foobar; if not, write to the Free Software
//    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

#ifndef GSTRING_H
#define GSTRING_H

namespace GaumerieLib
{

class GString
{

/*	- Constructeurs & Destructeurs ----------------------------------------	*/

	public:
	    	//	constructeur d'une chaine de caract�re vide
        GString();
        	//	constructeur par copie d'une chaine de caract�res
        	//	param�tre(s):
        	//		-	pointeurs vers la chaine de caract�res
        GString(const char*);
        	//	constructeur par accaparation d'un buffer
        	//	param�tre(s):
        	//		-	pointeurs vers le buffer
        	//		-	taille du buffer
        GString(char*, unsigned int);
        	//	constructeur par copie
        	//	param�tre(s):
        	//		-	r�f�rence vers le GString
		GString(const GString&);
			//	constructeur � partir d'un caract�re
			//	param�tre(s):
        	//		-	caract�re
        	//		-	nombre de r�p�titions du caract�re
        	//	Note:	si param1 = 0, cr�e une chaine vide de taille param2
		GString(char, unsigned int = 1);
			//	constructeur � partir d'un entier sign�
			//	param�tre(s):
        	//		-	entier sign�
		GString(int);
			//	constructeur � partir d'un entier non sign�
			//	param�tre(s):
        	//		-	entier non sign�
        	//		-	base
			//				0 : decimal
			//				1 : octal
			//				2 : hexad�cimal
		GString(unsigned int, unsigned char = 0);
			//	constructeur � partir d'un nombre � virgule
			//	param�tre(s):
			//		-	nombre � virgule
		GString(float);
			//	constructeur � partir d'un nombre � virgule
			//	param�tre(s):
			//		-	nombre � virgule
		GString(double);

			//	destructeur
		~GString();

/*	- Variables -----------------------------------------------------------	*/

	protected:
	    	//	pointeur vers le buffer
		char* tc_String;
			//	taille du buffer	/	taille de la chaine de caract�res
		unsigned int ui_SizeBuf, ui_SizeStr;

/*	- Fonctions contr�le variables ---------------------------------------- */

	//	Fonctions acc�s variables

	public:
	    	//	retourne un pointeur vers le buffer
		char* Text();
			//	retourne la taille du buffer
		unsigned int SizeBuffer();
			//	retourne la taille de la chaine de caract�res
		unsigned int SizeString();

	//	Fonctions gestions variables

	public:
	    	//	recalcule la taille de la chaine de caract�res
		void SizeStr_Verify();
			//	minimise la taille du buffer selon celle de la chaine de caract�res
		void SizeBuf_Minimum();
			//	change la taille du buffer
			//	Note:	Si la nouvelle taille est plus petite que celle de la chaine de caract�res,
			//		efface le buffer
		void SizeBuf_Resize(unsigned int);

			//	efface le GString
			//	param�tre(s):
			//		-	indique si il faut lib�rer le buffer
		void Clear(bool);
			//	affecte un buffer � la GString
			//	param�tre(s):
			//		-	pointeur vers le buffer
			//		-	taille du buffer
		void TakeBuffer(char*, unsigned int);
	
	//	Fonctions d'�change entre GString
	
	public:
	    	//	�change le contenu de deux GString
	    	//	param�tre(s):
	    	//		-	r�f�rence vers la GString avec laquelle �changer
	    void Exchange(GString&);
	    	//	prend le contenu de l'autre GString en la laissant vide
	    	//	param�tre(s):
	    	//		-	r�f�rence vers la GString o� prendre le contenu
	    void Take(GString&);


/*	- Fonctions d'analyse du contenu --------------------------------------	*/

	//	Operateurs de comparaison

	public:
	    	//	retourne true si la cha�ne est vide
	    bool operator ! () const;
	    
	    	//	retourne true si les deux cha�nes sont identiques
	    	//	param�tre(s):
	    	//		-	pointeur vers la cha�ne � comparer
	    bool operator == (const char*) const;
	    bool operator == (const GString&) const;
	    
	    	//	retourne true si les deux chaines sont diff�rentes
	    	//	param�tre(s):
	    	//		-	pointeur vers la cha�ne � comparer
	    bool operator != (const char*) const;
	    	//		-	r�f�rence vers la GString � comparer
	    bool operator != (const GString&) const;
	    
	    	//	returne true si l'instance est plus grande que l'autre cha�ne
	    	//	param�tre(s):
	    	//		-	pointeur vers la cha�ne � comparer
	    bool operator > (const char*) const;
	    	//		-	r�f�rence vers la GString � comparer
	    bool operator > (const GString&) const;
	    
	    	//	returne true si l'instance est plus grande ou �gale � l'autre cha�ne
	    	//	param�tre(s):
	    	//		-	pointeur vers la cha�ne � comparer
	    bool operator >= (const char*) const;
	    	//		-	r�f�rence vers la GString � comparer
	    bool operator >= (const GString&) const;
	    
	    	//	returne true si l'instance est plus petite que l'autre cha�ne
	    	//	param�tre(s):
	    	//		-	pointeur vers la cha�ne � comparer
	    bool operator < (const char*) const;
	    	//		-	r�f�rence vers la GString � comparer
	    bool operator < (const GString&) const;
	    
	    	//	returne true si l'instance est plus petite ou �gale � l'autre cha�ne
	    	//	param�tre(s):
	    	//		-	pointeur vers la cha�ne � comparer
	    bool operator <= (const char*) const;
	    	//		-	r�f�rence vers la GString � comparer
	    bool operator <= (const GString&) const;
	
	//	Fonctions de comparaison
	
	public:
	    	//	retourne true si la cha�ne est vide
	    bool IsEmpty() const;
	    
	    	//	compare les deux cha�nes de caract�res
	    	//	retour:
	    	//		-	1  : str1 > str2
	    	//		-	0  : str1 == str2
	    	//		-	-1 : str1 < str2
	    	
	    	//	param�tre(s):
	    	//		-	pointeur vers la cha�ne � comparer
	    char Compare(const char*) const;
	    	//	param�tre(s):
	    	//		-	r�f�rence vers la GString � comparer
		char Compare(const GString&) const;
			//	param�tre(s):
	    	//		-	caract�re � comparer
		char Compare(char) const;

			//	m�me fonction, mais seulement pour un nombre sp�cifi� de caract�res

			//	param�tre(s):
	    	//		-	pointeur vers la cha�ne � comparer
	    	//		-	nombre de caract�res � comparer
		char Compare(const char*, unsigned int) const;
			//	param�tre(s):
	    	//		-	r�f�rence vers la GString
	    	//		-	nombre de caract�res � comparer
		char Compare(const GString&, unsigned int) const;

	//	Fonctions de recherche

	public:
	    	//	retourne true si la cha�ne appara�t dans l'instance
	    	//	param�tre(s):
	    	//		-	pointeur vers la cha�ne � rechercher
	    bool Contains(const char*) const;
	    	//	param�tre(s):
	    	//		-	r�f�rence vers la GString � rechercher
	    bool Contains(const GString&) const;
	    	//	param�tre(s):
	    	//		-	caract�re � rechercher
	    bool Contains(char) const;

			//	retourne le nombre d'occurence dans l'instance
			//	param�tre(s):
	    	//		-	pointeur vers la cha�ne � rechercher
	    unsigned int Count(const char*) const;
	    	//	param�tre(s):
	    	//		-	r�f�rence vers la GString � rechercher
	    unsigned int Count(const GString&) const;
	    	//	param�tre(s):
	    	//		-	caract�re � rechercher
	    unsigned int Count(char) const;

			//	retourne l'index de la premi�re occurence dans l'instance
			//	param�tre(s):
	    	//		-	pointeur vers la cha�ne � rechercher
	    	//		-	index � partir de o� commencer
		int Search(const char*, unsigned int = 0) const;
			//	param�tre(s):
	    	//		-	r�f�rence vers la GString � rechercher
	    	//		-	index � partir de o� commencer
		int Search(const GString&, unsigned int = 0) const;
			//	param�tre(s):
	    	//		-	caract�re � rechercher
	    	//		-	index � partir de o� commencer
		int Search(char, unsigned int = 0) const;

		

/*	- Fonctions d'affectation ---------------------------------------------	*/

	public:
	    	//	copie une chaine de caract�re
			//	param�tre(s):
			//		-	pointeur vers la chaine de caract�res
		GString& operator = (const char*);
		GString& Copy(const char*);
			//	copie une GString
			//	param�tre(s):
			//		-	r�f�rence vers la GString
		GString& operator = (const GString&);
		GString& Copy(const GString&);
			//	copie un caract�re
			//	param�tre(s):
			//		-	caract�re
			//		-	nombre de r�p�titions du caract�re
			//	Note:	si param1 = 0, efface la chaine et v�rifie que le buffer
			//		ait une taille minimum de param2
		GString& operator = (char);
		GString& Char2String(char, unsigned int = 1);
			//	copie un entier sign�
			//	param�tre(s):
			//		-	entier sign�
		GString& operator = (int);
		GString& Int2String(int);
			//	copie un entier non sign�
			//	param�tre(s):
			//		-	entier non sign�
			//		-	base
			//				0 : decimal
			//				1 : octal
			//				2 : hexad�cimal
		GString& operator = (unsigned int);
		GString& UInt2String(unsigned int, unsigned char = 0);
			//	copie un nombre � virgule
			//	param�tre(s):
			//		-	nombre � virgule
		GString& operator = (float);
		GString& Float2String(float);
			//	copie un nombre � virgule
			//	param�tre(s):
			//		-	nombre � virgule
		GString& operator = (double);
		GString& Double2String(double);

	protected:
	    void S_Copy(const char*, unsigned int);

/*	- Fonctions de conversion ---------------------------------------------	*/

	public:
	    	//	retourne le pointeur vers le buffeur
		operator char*();
			//	retourne si la chaine de caract�res existe
		operator bool() const;
			//	retourne le premier caract�re de la chaine
		operator char() const;
		char ToChar() const;
			//	converti le d�but de la chaine en entier sign�
		operator int() const;
		int ToInt() const;
			//	converti le d�but de la chaine en entier non sign�
			//	param�tre(s):
			//		-	base
			//				0 : decimal
			//				1 : octal
			//				2 : d�cimal
		operator unsigned int() const;
		unsigned int ToUInt(unsigned char = 0) const;
			//	converti le d�but de la chaine en nombre � virgule
		operator float() const;
		float ToFloat() const;
			//	converti le d�but de la chaine en nombre � virgule
		operator double() const;
		double ToDouble() const;

/*	- Fonction acc�s ------------------------------------------------------	*/

	public:
	    	//	retourne une r�f�rence vers le n-�m- caract�re
	    	//	param�tre(s):
	    	//		-	index
		char& operator[](unsigned int);
	
	public:
	    	//	retoune une copie d'une partie de la cha�ne
	    	//	param�tre(s):
	    	//		-	index � partir de o� extraire
	    	//		-	nombre de caract�res � extraire
	    GString Extract_Mid(unsigned int, unsigned int) const;
	    	//	retoune la partie de la cha�ne allant d'un endroit sp�cifi� jusqu'� la fin
	    	//		-	index � partir de o� extraire
	    GString Extract_Right(unsigned int) const;

/*	- Fonctions ajout de chaines ------------------------------------------	*/

	public:
	    //	ajoute en fin de cha�ne
	    	//	une chaine de caract�re
			//	param�tre(s):
			//		-	pointeur vers la chaine de caract�res
		GString& operator += (const char*);
		GString& Append(const char*);
			//	une GString
			//	param�tre(s):
			//		-	r�f�rence vers la GString
		GString& operator += (const GString&);
		GString& Append(const GString&);
			//	un caract�re
			//	param�tre(s):
			//		-	caract�re
		GString& operator += (char);
		GString& Append(char);
			//	un entier sign�
			//	param�tre(s):
			//		-	entier sign�
		GString& operator += (int);
		GString& Append(int);
			//	un entier non sign�
			//	param�tre(s):
			//		-	entier non sign�
			//		-	base
			//				0 : decimal
			//				1 : octal
			//				2 : hexad�cimal
		GString& operator += (unsigned int);
		GString& Append(unsigned int, unsigned char = 0);
			//	un nombre � virgule
			//	param�tre(s):
			//		-	nombre � virgule
		GString& operator += (float);
		GString& Append(float);
			//	un nombre � virgule
			//	param�tre(s):
			//		-	nombre � virgule
		GString& operator += (double);
		GString& Append(double);
	protected:
	    void S_Append(const char*, unsigned int);
	
	public:
	    //	retourne une cha�ne �gale � l'instance ajout�e de:
	    	//	autre cha�ne
			//	param�tre(s):
			//		-	pointeur vers la chaine de caract�res
		GString operator + (const char*) const;
		GString Add(const char*) const;
			//	une GString
			//	param�tre(s):
			//		-	r�f�rence vers la GString
		GString operator + (const GString&) const;
		GString Add(const GString&) const;
			//	un caract�re
			//	param�tre(s):
			//		-	caract�re
		GString operator + (char) const;
		GString Add(char) const;
			//	un entier sign�
			//	param�tre(s):
			//		-	entier sign�
		GString operator + (int) const;
		GString Add(int) const;
			//	un entier non sign�
			//	param�tre(s):
			//		-	entier non sign�
			//		-	base
			//				0 : decimal
			//				1 : octal
			//				2 : hexad�cimal
		GString operator + (unsigned int) const;
		GString Add(unsigned int, unsigned char = 0) const;
			//	un nombre � virgule
			//	param�tre(s):
			//		-	nombre � virgule
		GString operator + (float) const;
		GString Add(float) const;
			//	un nombre � virgule
			//	param�tre(s):
			//		-	nombre � virgule
		GString operator + (double) const;
		GString Add(double) const;
	protected:
	    static GString S_Add(const char*, unsigned int, const char*, unsigned int);


	public:
	    //	ajoute en d�but de cha�ne
	    	//	une chaine de caract�re
			//	param�tre(s):
			//		-	pointeur vers la chaine de caract�res
		GString& Prepend(const char*);
			//	une GString
			//	param�tre(s):
			//		-	r�f�rence vers la GString
		GString& Prepend(const GString&);
			//	un caract�re
			//	param�tre(s):
			//		-	caract�re
		GString& Prepend(char);
			//	un entier sign�
			//	param�tre(s):
			//		-	entier sign�
		GString& Prepend(int);
			//	un entier non sign�
			//	param�tre(s):
			//		-	entier non sign�
			//		-	base
			//				0 : decimal
			//				1 : octal
			//				2 : hexad�cimal
		GString& Prepend(unsigned int, unsigned char = 0);
			//	un nombre � virgule
			//	param�tre(s):
			//		-	nombre � virgule
		GString& Prepend(float);
			//	un nombre � virgule
			//	param�tre(s):
			//		-	nombre � virgule
		GString& Prepend(double);
	protected:
	    void S_Prepend(const char*,unsigned int);


/*	- Fonctions d'insertion -----------------------------------------------	*/

	public:
	    //	insert � l'index sp�cifi�
	    	//	une cha�ne de caract�res
	    	//	param�tre(s):
			//		-	pointeur vers la chaine de caract�res
		GString& Insert(unsigned int, const char*);
			//	une GString
			//	param�tre(s):
			//		-	r�f�rence vers la GString
		GString& Insert(unsigned int, const GString&);
			//	un caract�re
			//	param�tre(s):
			//		-	caract�re
		GString& Insert(unsigned int, char);
			//	un entier sign�
			//	param�tre(s):
			//		-	entier sign�
		GString& Insert(unsigned int, int);
			//	un entier non sign�
			//	param�tre(s):
			//		-	entier non sign�
			//		-	base
			//				0 : decimal
			//				1 : octal
			//				2 : hexad�cimal
		GString& Insert(unsigned int, unsigned int, unsigned char = 0);
			//	un nombre � virgule
			//	param�tre(s):
			//		-	nombre � virgule
		GString& Insert(unsigned int, float);
			//	un nombre � virgule
			//	param�tre(s):
			//		-	nombre � virgule
		GString& Insert(unsigned int, double);
	protected:
	    void S_Insert(char*, const char*, unsigned int);


/*	- Fonctions de remplacement d'occurences ------------------------------	*/

	public:
	    //	remplace la premi�re occurence de l'argument d'index le plus bas
	    //		( "%0", "%1", "%2", ..., "%9"	)
	    	//	par une cha�ne de caract�res
	    	//	param�tre(s):
			//		-	pointeur vers la chaine de caract�res
	    GString& operator () (const char*);
	    GString& Arg(const char*);
	    	//	par une GString
	    	//	param�tre(s):
			//		-	r�f�rence vers la GString
		GString& operator () (const GString&);
		GString& Arg(const GString&);
			//	par un caract�re
			//	param�tre(s):
			//		-	caract�re
		GString& operator () (char);
		GString& Arg(char);
			//	par un entier sign�
			//	ajoute un entier sign� en d�but de cha�ne
			//	param�tre(s):
			//		-	entier sign�
		GString& operator () (int);
		GString& Arg(int);
			//	par un entier non sign�
			//	param�tre(s):
			//		-	entier non sign�
		GString& operator () (unsigned int);
		GString& Arg(unsigned int);
			//	par un nombre � virgule
			//	param�tre(s):
			//		-	nombre � virgule
		GString& operator () (float);
		GString& Arg(float);
			//	par un nombre � virgule
			//	param�tre(s):
			//		-	nombre � virgule
		GString& operator () (double);
		GString& Arg(double);


	//	remplace la premi�re occurence de l'argument d'index sp�cifi�
			//	par une cha�ne de caract�res
	    	//	param�tre(s):
			//		-	pointeur vers la chaine de caract�res
			//		-	index de l'argument
		GString& operator () (const char*, unsigned char);
		GString& Arg(const char*, unsigned char);
			//	par une GString
	    	//	param�tre(s):
			//		-	r�f�rence vers la GString
			//		-	index de l'argument
		GString& operator () (const GString&, unsigned char);
		GString& Arg(const GString&, unsigned char);
			//	par un caract�re
			//	param�tre(s):
			//		-	caract�re
			//		-	index de l'argument
		GString& operator () (char, unsigned char);
		GString& Arg(char, unsigned char);
			//	par un entier sign�
			//	ajoute un entier sign� en d�but de cha�ne
			//	param�tre(s):
			//		-	entier sign�
			//		-	index de l'argument
		GString& operator () (int, unsigned char);
		GString& Arg(int, unsigned char);
			//	par un entier non sign�
			//	param�tre(s):
			//		-	entier non sign�
			//		-	index de l'argument
		GString& operator () (unsigned int, unsigned char);
		GString& Arg(unsigned int, unsigned char);
			//	par un nombre � virgule
			//	param�tre(s):
			//		-	nombre � virgule
			//		-	index de l'argument
		GString& operator () (float, unsigned char);
		GString& Arg(float, unsigned char);
			//	par un nombre � virgule
			//	param�tre(s):
			//		-	nombre � virgule
			//		-	index de l'argument
		GString& operator () (double, unsigned char);
		GString& Arg(double, unsigned char);
	protected:
		char* S_SearchArg();
		char* S_SearchArg(unsigned char);
		void S_ReplaceArg_Str(char*, const char*, unsigned int);
		void S_ReplaceArg_Char(char*, char);

/*	- Fonctions de remplacement -------------------------------------------	*/


	public:
		//	remplace un certain nombre de caract�re � partir d'un index
			//	par une cha�ne de caract�res
			//	param�tre(s):
			//		-	index � partir duquel il faut remplacer
			//		-	nombre de caract�res � remplacer
			//		-	pointeur vers la chaine de caract�res
		GString& Replace(unsigned int, unsigned int, const char*);
			//	par une GString
			//	param�tre(s):
			//		-	index � partir duquel il faut remplacer
			//		-	nombre de caract�res � remplacer
			//		-	r�f�rence vers la GString
		GString& Replace(unsigned int, unsigned int, const GString&);
			//	par un caract�re
			//	param�tre(s):
			//		-	index � partir duquel il faut remplacer
			//		-	nombre de caract�res � remplacer
			//		-	caract�re
		GString& Replace(unsigned int, unsigned int, char);
			//	par un entier sign�
			//	param�tre(s):
			//		-	index � partir duquel il faut remplacer
			//		-	nombre de caract�res � remplacer
			//		-	entier sign�
		GString& Replace(unsigned int, unsigned int, int);
			//	par un entier non sign�
			//	param�tre(s):
			//		-	index � partir duquel il faut remplacer
			//		-	nombre de caract�res � remplacer
			//		-	entier non sign�
			//		-	base dans laquelle mettre l'entier non sign�
		GString& Replace(unsigned int, unsigned int, unsigned int, unsigned char = 0);
			//	par un nombre � virgule
			//	param�tre(s):
			//		-	index � partir duquel il faut remplacer
			//		-	nombre de caract�res � remplacer
			//		-	nombre � virgule
		GString& Replace(unsigned int, unsigned int, float);
			//	par un nombre � virgule
			//	param�tre(s):
			//		-	index � partir duquel il faut remplacer
			//		-	nombre de caract�res � remplacer
			//		-	nombre � virgule
		GString& Replace(unsigned int, unsigned int, double);

		//	remplace l'/les occurence(s)
		
		//	d'une cha�ne de caract�res
			//	par une cha�ne de caract�res
			//	param�tre(s):
			//		-	pointeur vers la cha�ne � remplacer
			//		-	pointeur vers la chaine de caract�res
			//		-	si il faut remplacer toutes les occurences
		GString& Replace(const char*, const char*, bool = false);
			//	par une GString
			//	param�tre(s):
			//		-	pointeur vers la cha�ne � remplacer
			//		-	r�f�rence vers la GString
			//		-	si il faut remplacer toutes les occurences
		GString& Replace(const char*, const GString&, bool = false);
			//	par un caract�re
			//	param�tre(s):
			//		-	pointeur vers la cha�ne � remplacer
			//		-	caract�re
			//		-	si il faut remplacer toutes les occurences
		GString& Replace(const char*, char, bool = false);
			//	par un entier sign�
			//	param�tre(s):
			//		-	pointeur vers la cha�ne � remplacer
			//		-	entier sign�
			//		-	si il faut remplacer toutes les occurences
		GString& Replace(const char*, int, bool = false);
			//	par un entier non sign�
			//	param�tre(s):
			//		-	pointeur vers la cha�ne � remplacer
			//		-	entier non sign�
			//		-	base dans laquelle mettre l'entier non sign�
			//		-	si il faut remplacer toutes les occurences
		GString& Replace(const char*, unsigned int, unsigned char = 0, bool = false);
			//	par un nombre � virgule
			//	param�tre(s):
			//		-	pointeur vers la cha�ne � remplacer
			//		-	nombre � virgule
			//		-	si il faut remplacer toutes les occurences
		GString& Replace(const char*, float, bool = false);
			//	par un nombre � virgule
			//	param�tre(s):
			//		-	pointeur vers la cha�ne � remplacer
			//		-	nombre � virgule
			//		-	si il faut remplacer toutes les occurences
		GString& Replace(const char*, double, bool = false);

		//	d'une GString
			//	par une cha�ne de caract�res
			//	param�tre(s):
			//		-	r�f�rence vers la GString � remplacer
			//		-	pointeur vers la chaine de caract�res
			//		-	si il faut remplacer toutes les occurences
		GString& Replace(const GString&, const char*, bool = false);
			//	par une GString
			//	param�tre(s):
			//		-	r�f�rence vers la GString � remplacer
			//		-	r�f�rence vers la GString
			//		-	si il faut remplacer toutes les occurences
		GString& Replace(const GString&, const GString&, bool = false);
			//	par un caract�re
			//	param�tre(s):
			//		-	r�f�rence vers la GString � remplacer
			//		-	caract�re
			//		-	si il faut remplacer toutes les occurences
		GString& Replace(const GString&, char, bool = false);
			//	par un entier sign�
			//	param�tre(s):
			//		-	r�f�rence vers la GString � remplacer
			//		-	entier sign�
			//		-	si il faut remplacer toutes les occurences
		GString& Replace(const GString&, int, bool = false);
			//	par un entier non sign�
			//	param�tre(s):
			//		-	r�f�rence vers la GString � remplacer
			//		-	entier non sign�
			//		-	base dans laquelle mettre l'entier non sign�
			//		-	si il faut remplacer toutes les occurences
		GString& Replace(const GString&, unsigned int, unsigned char = 0, bool = false);
			//	par un nombre � virgule
			//	param�tre(s):
			//		-	r�f�rence vers la GString � remplacer
			//		-	nombre � virgule
			//		-	si il faut remplacer toutes les occurences
		GString& Replace(const GString&, float, bool = false);
			//	par un nombre � virgule
			//	param�tre(s):
			//		-	r�f�rence vers la GString � remplacer
			//		-	nombre � virgule
			//		-	si il faut remplacer toutes les occurences
		GString& Replace(const GString&, double, bool = false);

		//	d'un caract�re
			//	par une cha�ne de caract�res
			//	param�tre(s):
			//		-	le caract�re � remplacer
			//		-	pointeur vers la chaine de caract�res
			//		-	si il faut remplacer toutes les occurences
		GString& Replace(char, const char*, bool = false);
			//	par une GString
			//	param�tre(s):
			//		-	caract�re � remplacer
			//		-	r�f�rence vers la GString
			//		-	si il faut remplacer toutes les occurences
		GString& Replace(char, const GString&, bool = false);
			//	par un caract�re
			//	param�tre(s):
			//		-	caract�re � remplacer
			//		-	caract�re
			//		-	si il faut remplacer toutes les occurences
		GString& Replace(char, char, bool = false);
			//	par un entier sign�
			//	param�tre(s):
			//		-	caract�re � remplacer
			//		-	entier sign�
			//		-	si il faut remplacer toutes les occurences
		GString& Replace(char, int, bool = false);
			//	par un entier non sign�
			//	param�tre(s):
			//		-	caract�re � remplacer
			//		-	entier non sign�
			//		-	base dans laquelle mettre l'entier non sign�
			//		-	si il faut remplacer toutes les occurences
		GString& Replace(char, unsigned int, unsigned char = 0, bool = false);
			//	par un nombre � virgule
			//	param�tre(s):
			//		-	caract�re � remplacer
			//		-	nombre � virgule
			//		-	si il faut remplacer toutes les occurences
		GString& Replace(char, float, bool = false);
			//	par un nombre � virgule
			//	param�tre(s):
			//		-	caract�re � remplacer
			//		-	nombre � virgule
			//		-	si il faut remplacer toutes les occurences
		GString& Replace(char, double, bool = false);
	protected:
	    void S_Replace_Str(char*, unsigned int, const char*, unsigned int);
	    void S_Replace_Char(char*, unsigned int, char);
	    void S_Replace_All_Str2Str(const char*, unsigned int, const char*, unsigned int);
	    void S_Replace_All_Str2Char(const char*, unsigned int, char);
	    void S_Replace_All_Char2Str(char, const char*, unsigned int);
	    void S_Replace_All_Char2Char(char, char);
	
/*	- Fonctions amies de la classe ----------------------------------------	*/

	public:
	    friend GString operator + (const char*, const GString&);
		friend GString operator + (char, const GString&);
		friend GString operator + (int, const GString&);
		friend GString operator + (unsigned int, const GString&);
		friend GString operator + (float, const GString&);
		friend GString operator + (double, const GString&);

};

};

#endif
