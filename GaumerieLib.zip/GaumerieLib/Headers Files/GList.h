//    This file is part of Gaumerie (C)2006-2007 ClassPad.fr

//    Gaumerie is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.

//    Gaumerie is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Foobar; if not, write to the Free Software
//    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

#ifndef GLIST_H
#define GLIST_H

	/*	Librairie "GaumerieLib.lib"
		�crite par Alexandre Rion (gaumerie@hotmail.com)	*/

#ifdef WIN32
#error "These functions only work on Casio ClassPad300"
#endif	/*  WIN32  */
#ifndef __cplusplus
#error "These functions can only be used in C++"
#endif	/*  __cplusplus  */

	/**	STRUCTURES DE GESTIONS DE LISTES CHAIN�ES	**/

//	Fichier(s) Source	:	GList.asm
//	Librairie		:	GaumerieLib.lib

namespace GaumerieLib
{
	//	Structure de base de la cha�ne
struct GLink
{
        	//	pointeur vers le le lien suivant
	GLink* pGLk_Next;
		//	pointeur vers l'objet
	void* pv_Obj;

		//	constructeur(s)
	GLink(void* pv_cObj, GLink* pGLk_cNext):
		pv_Obj(pv_cObj), pGLk_Next(pGLk_cNext)
		{	}
};
	//	Classe de gestion de la cha�ne
class GList
{
	friend class GListIterator;

	protected:
		//	pointeurs vers le dernier lien de la cha�ne
	GLink* pGLk_Last;
		//	nombre d'�l�ments de la cha�ne
	unsigned int ui_Size;

	public:
		//	constructeur(s)        
	GList():
		pGLk_Last(0), ui_Size(0)
		{	}
	GList(void* pv_cObj):
		ui_Size(1), pGLk_Last(new GLink(pv_cObj,0))
		{	pGLk_Last->pGLk_Next = pGLk_Last;	}
		//	destructeur
	~GList()
		{	Clear();	}

		//	retourne l'addresse du premier lien de la cha�ne
	GLink* First_Link()
		{	return pGLk_Last->pGLk_Next;	}
		//	retourne l'addresse du premier objet de la cha�ne
	void* First()
		{	return pGLk_Last->pGLk_Next->pv_Obj;	}
		//	retourne l'addresse du dernier lien de la cha�ne
	GLink* Last_Link()
		{	return pGLk_Last;	}
		//	retourne l'addresse du dernier objet de la cha�ne
	void* Last()
		{	return pGLk_Last->pv_Obj;	}
		//	retourne le nombre d'�l�ments de la cha�ne
	unsigned int Size()
		{	return ui_Size;	}

		//	retourne si l'objet est contenu dans la cha�ne
	bool Contains(const void*) const;

		//	insert un objet en t�te de la cha�ne
	void InsertHead(const void*);
		//	insert un objet en fin de la cha�ne
	void InsertEnd(const void*);
		//	insert un objet avant (la premi�re occurence d') un autre
	bool InsertBefore(const void*, const void*);
		//	insert un objet apr�s (la premi�re occurence d') un autre
	bool InsertAfter(const void*, const void*);

		//	remplace (la premi�re occurence d') un objet par un autre
	bool Replace(const void*, const void*);

		//	retire (la premi�re occurence d') un objet de la cha�ne
	bool Remove(const void*);

		//	efface la cha�ne
	void Clear();
		//	efface la cha�ne et d�truit les �l�ments qu'elle contient
	void Destroy();

		//	prend la cha�ne d'un autre GList
	void Take(GList*);
		//	copie la cha�ne d'une autre GList
	void Copy(const GList*);
};
	//	Classe d'it�ration de la cha�ne
class GListIterator
{
        	//	addresse du lien actuel
        GLink* pGLk_Act;
        	//	nombre d'�l�ments restants dans la cha�ne
        unsigned int ui_Count;
        	//	addresse de la GList
	const GList* pGLst_List;

	public:
	        //	contructeur(s)
	GListIterator(GList* pGLst):
		pGLst_List(pGLst), pGLk_Act(pGLst->pGLk_Last), ui_Count(pGLst->ui_Size)
		{	}

		//	initialise la structure et retourne l'addresse du premier objet de la cha�ne
	void* First()
		{
			ui_Count = pGLst_List->ui_Size;
			if(ui_Count)
			{
				pGLk_Act = pGLst_List->pGLk_Last->pGLk_Next;
				return pGLk_Act->pv_Obj;
			}
			return 0;
		}
		//	passe � l'objet suivant de la cha�ne et retourne son addresse
	void* Next()
		{
			if(ui_Count && --ui_Count)
			{
				pGLk_Act = pGLk_Act->pGLk_Next;
				return pGLk_Act->pv_Obj;
			}
			return 0;
		}
		//	retourne l'addresse de l'objet actuel
	void* Object()
		{
			return pGLk_Act->pv_Obj;
		}
		//	retourne l'adresse du lien actuel
	GLink* Link()
		{
			return pGLk_Act;
		}
};

};

#endif	/*  GLIST_H  */
