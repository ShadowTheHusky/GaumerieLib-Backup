//    This file is part of Gaumerie (C)2006-2007 ClassPad.fr

//    Gaumerie is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.

//    Gaumerie is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Foobar; if not, write to the Free Software
//    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

#ifndef GETKEY_H
#define GETKEY_H

	/*	Librairie "GaumerieLib.lib"
		�crite par Alexandre Rion (gaumerie@hotmail.com)	*/

#ifdef WIN32
#error "These functions only work on Casio ClassPad300"
#endif	/*  WIN32  */
#ifndef __cplusplus
#error "These functions can only be used in C++"
#endif	/*  __cplusplus  */

	/**	FONCTION DE V�RIFICATION DE L'�TAT DES TOUCHES	**/

//  Fonction initialement cr��e par Brian Maguire ( brianm@classpad.org )

//	Fichier(s) Source	:	GetKey.asm
//	Librairie		:	GaumerieLib.lib

/*
    Codes touches ( KEY_CODE ):
        Keyboard : 0x75         Haut : 0x74         ON/OFF : 0x10
                Gauche : 0x63                   Droite : 0x73
        <- : 0x71               Bas : 0x64          Clear : 0x72

        = : 0x76  x : 0x66  y : 0x65  z : 0x53  ^ : 0x62  � : 0x61
         ( : 0x56    7 : 0x55    8 : 0x54    9 : 0x52    X : 0x51
         ) : 0x46    4 : 0x45    5 : 0x44    6 : 0x42    - : 0x41
         , : 0x36    1 : 0x35    2 : 0x34    3 : 0x32    + : 0x31
        (-): 0x26    0 : 0x25    . : 0x24   EXP: 0x22   EXE: 0x21

    /!\ Les touches "Keyboard", "ON/OFF" et "Clear" n'envoyent pas de PegMessage
            PM_KEY
*/

namespace GaumerieLib
{

namespace GetKey
{
        	//	codes des touches
        enum	KEY_CODE	{
                K_ONOFF	= 0x10,
                K_EXE	= 0x21,	K_EXP,	K_DOT	= 0x24,	K_0,	K_OPPOSIT,
                K_PLUS	= 0x31,	K_3,	K_2	= 0x34,	K_1,	K_COMMA,
                K_MINUS	= 0x41,	K_6,	K_5	= 0x44,	K_4,	K_RPAR,
                K_TIMES	= 0x51,	K_9,	K_Z,	K_8,	K_7,	K_LPAR,
                K_DIV	= 0x61,	K_POWER,K_LEFT,	K_DOWN,	K_Y,	K_X,
                K_BACK	= 0x71,	K_CLEAR,K_RIGHT,K_UP,	K_KEYBOARD,	K_EQUAL
        };
		//	retourne l'�tat de la touche sp�cifi�e
	bool GetKey(KEY_CODE);
};

};

#endif	/*  GETKEY_H  */
