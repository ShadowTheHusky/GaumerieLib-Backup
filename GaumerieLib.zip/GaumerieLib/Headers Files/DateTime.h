//    This file is part of Gaumerie (C)2006-2007 ClassPad.fr

//    Gaumerie is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.

//    Gaumerie is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Foobar; if not, write to the Free Software
//    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

#ifndef DATETIME_H
#define DATETIME_H

    /*  Librairie "GaumerieLib.lib"
            �crite par Alexandre Rion (gaumerie@hotmail.com)    */

#ifdef WIN32
#error "These functions only work on Casio ClassPad300"
#endif

    /** FONCTIONS DE TRANSFORMATION DE DONN�ES BCD ET NUM�RIQUES **/
                /*  N�cessite les librairies "libc.lib"  */

#ifdef __cplusplus
extern "C"{
#endif

    void LibBCD2Ascii(unsigned char, unsigned char*);
    unsigned char LibAscii2BCD(unsigned char*);
    unsigned char LibChangeBcdVal(unsigned char);
    unsigned char LibChangeValBcd(unsigned char);

#ifdef __cplusplus
}
#endif

        /** STRUCTURE DE GESTION DES DONN�ES DE DATE ET D'HEURE **/
                /*  N�cessite le fichier "DateTime.cpp"  */

	//	defines : valeur des jours de la semaine
#define RTC_WD_SUNDAY       0x00
#define RTC_WD_MONDAY       0x01
#define RTC_WD_TUESDAY      0x02
#define RTC_WD_WEDNESDAY    0x03
#define RTC_WD_THURSDAY     0x04
#define RTC_WD_FRIDAY       0x05
#define RTC_WD_SATURDAY     0x06

	//	defines : masque d'activation de chaque donn�e
#define DT_ENB_SECONDE      0x01
#define DT_ENB_MINUTE       0x02
#define DT_ENB_HOUR         0x04
#define DT_ENB_WEEKDAY      0x08
#define DT_ENB_DAY          0x10
#define DT_ENB_MONTH        0x20
#define DT_ENB_YEAR         0x40

namespace GaumerieLib
{

    //  structure de base pour le stockage des donn�es de date et d'heure
struct DateTime
{
        //  donn�es
        //  /!\ ne jamais changer leur ordre ni ajouter dautres variables avant
    unsigned char uc_Seconde;   //  secondes    (en BCD)
    unsigned char uc_Minute;    //  minutes     (en BCD)
    unsigned char uc_Hour;      //  heures      (en BCD)
    unsigned char uc_WeekDay;   //  jour de la semaine (voir defines "RTC_WD_")
    unsigned char uc_Day;       //  jour        (en BCD)
    unsigned char uc_Month;     //  mois        (en BCD)
    unsigned char uc_Year;      //  2 derni�s chiffres de l'ann�e   (en BCD)
    unsigned char uc_MaskEnb;   //  masque des donn�es � prendre en compte
        /*  bit 0 : uc_Seconde          bit 5 : uc_Day
            bit 1 : uc_Minutes          bit 6 : uc_Month
            bit 2 : uc_Hour             bit 7 : uc_Year
            bit 4 : uc_WeekDay                              
            
            0 : pas pris en compte      1 : pris en compte  */

        //  v�rifie si les donn�es peuvent �tre correcte
        //      PS: * v�rifie seulement que ca corresponde � quelque chose de coh�rant,
        //  pas que le jour de la semaine soit correcte, ou que le mois comprenne
        //  suffisament de jours
        //          * v�rifie seulement les donn�es sp�cifi�es par la variable "uc_MaskEnb"
    bool IsValid()
    {
        return !(
    	(uc_MaskEnb&0x01 && (uc_Seconde>0x59     ||  (uc_Seconde&0x0F)>9    ))|
        (uc_MaskEnb&0x02 && (uc_Minute>0x59      ||  (uc_Minute&0x0F)>9     ))|
        (uc_MaskEnb&0x04 && (uc_Hour>0x23        ||  (uc_Hour&0x0F)>9       ))|
        (uc_MaskEnb&0x08 && (uc_WeekDay>6                                   ))|
        (uc_MaskEnb&0x10 && (uc_Day>0x31         ||  (uc_Day&0x0F)>9        ))|
        (uc_MaskEnb&0x20 && (uc_Month>0x12       ||  (uc_Month&0x0F)>9      ))|
        (uc_MaskEnb&0x40 && (uc_Year>0x99        ||  (uc_Year&0x0F)>9       )));
    }    
};

};

#endif
