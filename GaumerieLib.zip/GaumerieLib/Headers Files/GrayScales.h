//    This file is part of Gaumerie (C)2006-2007 ClassPad.fr

//    Gaumerie is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.

//    Gaumerie is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Foobar; if not, write to the Free Software
//    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

#ifndef GRAYSCALES_H
#define GRAYSCALES_H

	/*	Librairie "GaumerieLib.lib"
		�crite par Alexandre Rion (gaumerie@hotmail.com)	*/

#ifdef WIN32
#error "These functions only work on Casio ClassPad300"
#endif	/*  WIN32  */
#ifndef __cplusplus
#error "These functions can only be used in C++"
#endif	/*  __cplusplus  */

	/**	FONCTIONS DE CONTR�LE DU CONTRASTE DE L'�CRAN	**/

//	Fichier(s) Source	:	---
//	Librairie		:	BIOSLIB.lib - libc.lib

	//	defines	:	void Bdisp_ContrastSet_DD(unsigned char)
#define CONTRAST_MIN 26		//	contraste minimum
#define CONTRAST_INI 38		//	contraste initial
#define CONTRAST_MAX 50		//	contraste maximum

extern "C"
{
		//	donne l'�tat actuel du contraste de l'�cran(26-50)
	unsigned char Bdisp_ContrastOut_DD();
		//	fixe le contraste de l'�cran(26-50)
	void Bdisp_ContrastSet_DD(unsigned char);

		//	remet le contraste de l'�cran � son �tat initial (38)
	void LibContrastInit();
		//	augmente le contraste de l'�cran de 1 (quand passe au-del� de 50, retourne � 38)
	void LibContrastUp();
		//	diminue le contraste de l'�cran de 1 (quand passe au-dessous de 26, retourne � 38)
	void LibContrastDown();
}

	/** FONCTIONS DE CR�ATION ET DE GESTION DE NUANCES DE GRIS **/

//	Fichier Source		:	GrayScales.asm
//	Librairie		:	GaumerieLib.lib

/*
	/!\	Monopolise le SH3Timer 0
*/

namespace GaumerieLib
{

        typedef unsigned char BITMAP;

namespace GrayScales
{
		//	sauvegarde l'�tat initial et initialise le timer utilis� par les nuances
	void Initialize();
		//	restore l'�tat initial du timer
	void Restore();

		//	fixe l'addresse des buffers utilis�s
	void SetBuffers(BITMAP*, BITMAP*);
		//	retourne l'addresse des buffers utilis�s
	void GetBuffers(BITMAP**, BITMAP**);

		//	lance l'appel p�riodique de l'interruption
	void Start();
		//	arr�te l'appel p�riodique de l'interruption
	void Stop();
};

};

#endif	/*  GRAYSCALES_H  */
