//    This file is part of Gaumerie (C)2006-2007 ClassPad.fr

//    Gaumerie is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.

//    Gaumerie is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Foobar; if not, write to the Free Software
//    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

#ifndef SH3TIMER_H
#define SH3TIMER_H

	/*	Librairie "GaumerieLib.lib"
		�crite par Alexandre Rion (gaumerie@hotmail.com)	*/

#ifdef WIN32
#error "These functions only work on Casio ClassPad300"
#endif	/*  WIN32  */
#ifndef __cplusplus
#error "These functions can only be used in C++"
#endif	/*  __cplusplus  */

        /** FONCTIONS DE CONTR�LE DES TIMERS DU PROCESSEUR **/

//	Fichier(s) Source	:	SH3Timers.asm
//	Librairie		:	GaumerieLib.lib

    //  defines : fr�quences des horloges des timers (valeurs r�elles)
#define CLKFRQ_3MHZ     3682419
#define CLKFRQ_920KHZ   920385
#define CLKFRQ_230KHZ   230147
#define CLKFRQ_57KHZ    57538

    /* LISEZ-MOI */
/* Qu'est ce qu'un SH3Timer? :
        -	C'est un registre de 32 bits du processeur qui se d�cr�mente � une fr�quence fix�e.
    Une fois la valeur du registre arriv�e � 0, celui-ci reprend une certaine valeur pour reprendre son
    compte-�-rebour et indique son passage � 0 dans un indicateur qui peut �tre lu et effac�, ou qui
    provoque une interruption.
*/
/* Comment utiliser les SH3Timers? :
    -   Lancer un timer :
        1�  Fixer la fr�quence de l'horloge du timer avec la fonction SH3Timer_SetClockFreq
        2�  Fixer la valeur initialie du timer avec la fonction SH3Timer_SetCount
        3�  Fixer la valeur � laquelle le timer doit retourner apr�s un passage � 0 avec la fonction SH3Timer_SetTimerFreq
        4�  Lancer le timer avec la fonction SH3Timer_Start
    -   Verifier l'avancement d'un timer :
        *  	V�rifier sa valeur actuelle avec la fonction SH3Timer_GetCount
        *	V�rifier si un passage � 0 s'est produit et effacer l'indicateur avec la fonction SH3Timer_HasUnderflowed
    -   Arr�ter un timer :
        *  	Arr�ter le timer avec la fonction SH3Timer_Stop
*/
/*  Notes:
    -   Il existe d'autres horloge sur lesquelles les timers peuvent se baser, mais certaines ne doivent pas �tre utilis�es. C'est pourquoi la fonction SH3Timer_GetClockFreq peut retourner une valeur inconnue si la fr�quence de l'horloge n'a pas �t� au pr�alable initialis�e
    -	Les fonctions de g�n�rations d'interruptions ne sont pas mises � disposition d�lib�r�ment suite � des divergences de point de vue.
	-   Invalidit� des param�tres:
	    *	si le param�tre uc_Timer est invalide, la fonction ne produit rien ou retourne une valeur sans signification
    	*   la fonction SH3Timer_SetClockFreq ne garde que les 3 bits le splus bas du param�tre uc_ClkFrq
*/
/*	/!\
    -	Les registres de valeur des timers peuvent �tre lus pendants que ceux-ci sont en route sans que la valeur soit fauss�e.
		Mais chaque compteur doit �tre arr�t� avant de lui assigner une valeur directement. 
    - 	Les timers continuent leur d�cr�mentation m�me lorsque la Classpad est �teinte ou l'application quitt�e, veillez donc � arr�ter tous les timers avant ces deux cas.
    -	LE TIMER NUM�RO 2 A UNE INTERRUPTION QUI LUI EST FIX�E, ET SON UTILISATION SE VOIT R�DUITE SI ON NE LA D�SACTIVE PAS. (s'arr�te � chaque passage � 0 en plus de son effet encore inconnu)
*/

namespace GaumerieLib
{

        typedef void (INTERRUPT)(void);
	typedef unsigned int STATUS_REG;

namespace SH3Timer
{
        	//	timers
	enum	TIMER	{
	        TIMER_0  = 0x00,	TIMER_1,	TIMER_2
	};
		//	fr�quences de l'horloge des timers
	enum	FREQUENCE	{
	        FRQ_3MHZ = 0x00,	FRQ_920KHZ,	FRQ_230KHZ,
	        FRQ_57KHZ
	};
		//  lance le timer correspondant
	void Start(TIMER);
		//  lance les 3 timers en m�me temps
	void StartAll();
		//  arr�te le timer correspondant
	void Stop(TIMER);
		//  arr�te les 3 timers en m�me temps
	void StopAll();
		//  retourne "true" si le timer correspondant est lanc�
	bool GetState(TIMER);

		//  fixe la fr�quence de l'horloge du timer
	void SetClockFreq(TIMER, FREQUENCE);
		//  retourne la fr�quence de l'horloge du timer
	FREQUENCE GetClockFreq(TIMER);

		//  fixe la valeur d'initialisation du timer apr�s un passage � 0
	void SetTimerFreq(TIMER, unsigned int);
		//  retourne la valeur d'initialisation du timer apr�s un passage � 0
	unsigned int GetTimerFreq(TIMER);

		//  fixe la valeur actuelle du registre de comptage du timer
	void SetCount(TIMER, unsigned int);
		//  fixe la valeur actuelle du registre de comptage du timer
	unsigned int GetCount(TIMER);

		//  retourne si un passage � 0 s'est produit et efface l'indicateur si c'est le cas
	bool HasUnderflowed(TIMER);
		//  efface l'indicateur de passage � 0
	void ClearUNFlag(TIMER);

};

};

#endif	/*  SH3TIMER_H  */
