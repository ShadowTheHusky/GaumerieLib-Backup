//    This file is part of Gaumerie (C)2006-2007 ClassPad.fr

//    Gaumerie is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.

//    Gaumerie is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Foobar; if not, write to the Free Software
//    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

#ifndef RTCALARM_H
#define RTCALARM_H

	/*	Librairie "GaumerieLib.lib"
		�crite par Alexandre Rion (gaumerie@hotmail.com)	*/

#ifdef WIN32
#error "These functions only work on Casio ClassPad300"
#endif	/*  WIN32  */
#ifndef __cplusplus
#error "These functions can only be used in C++"
#endif	/*  __cplusplus  */

	//	include : structure de base pour la gestion des donn�es de date et d'heure
#ifdef GLIB_COMP
#include "HEADER~1/DateTime.h"
#else
#include "GAUMER~1/HEADER~1/DateTime.h"
#endif	/*  GLIB_COMP  */

	/**	FONCTIONS DE CONTR�LE DE L'INTERRUPTION DU SYST�ME D'ALARME	**/

//	Fichier(s) Source	:	RTCAlarm.asm
//	Librairie		:	GaumerieLib.lib

namespace GaumerieLib
{

	typedef void (INTERRUPT)(void);
	typedef unsigned int STATUS_REG;

namespace RTCClock
{
		//	fixe le niveau de priorit� des interruptions li�es � l'horloge en temps r�el
	void SetIntPriority(unsigned char);
		//	retourne le niveau de priorit� des interruptions li�es � l'horloge en temps r�el
	unsigned char GetIntPriority();
};

namespace RTCAlarm
{
		//	fixe les registres de date et d'heure de l'alarme
	void SetDateTime(const DateTime&);
		//	retourne l'�tat des registres de date et d'heure de l'alarme
	void GetDateTime(DateTime&);
		//	fixe les donn�es � prendre en compte pour l'alarme
	void SetEnb(unsigned char);

		//	efface l'indicateur d'interruption
	void ClearAFlag();
};

};

#endif	/*  RTCALARM_H  */
