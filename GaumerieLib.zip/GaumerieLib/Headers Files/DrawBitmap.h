//    This file is part of Gaumerie (C)2006-2007 ClassPad.fr

//    Gaumerie is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.

//    Gaumerie is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Foobar; if not, write to the Free Software
//    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

#ifndef DRAW_H
#define DRAW_H

#ifdef GLIB_COMP
#include "HEADER~1/GStructs.h"
#else
#include "GAUMER~1/HEADER~1/GStructs.h"
#endif

    /*  Librairie "GaumerieLib.lib"
            �crite par Alexandre Rion (gaumerie@hotmail.com)    */

#ifdef WIN32
#error "These functions only work on Casio ClassPad300"
#endif


	//	defines : adresse et dimensions du buffer temporaire de l'�cran
#define VRAM_ADRS   0x8C0189A8
#define VRAM_DIM    160,240

namespace GaumerieLib
{

		/*** FONCTION D'ACCES DIRECT A LA M�MOIRE DE L'�CRAN ***/
	
	//	copie un buffer de 20*240 octets directement dans la m�moire de l'�cran
extern "C" void CopyToScreen(const unsigned char* tuc_Src);
	//	copie la m�moire de l'�cran dans un buffer de 20*240 octets
extern "C" void CopyFromScreen(unsigned char* tuc_Dest);


				/*** FONCTIONS D'AFFICHGE DE BITMAPS ***/

    //  fonction principale
extern "C" void DrawBitmapASM(const unsigned char*,int,int,int,int,unsigned char*,int,int,unsigned char,const unsigned char*,const unsigned char*);


            /*** FONCTIONS D'AFFICHAGE D'UNE BITMAP SIMPLE ***/
					/* (1 bitmap - nuances : 1 buffer ) */
	//	copie la bitmap telle quelle
#define DRAWBITMAP_COPY 0x00
	//	force au noir les pixels correspondants aux pixels noirs de la bitmap
#define DRAWBITMAP_OR   0x01
	//	inverse les pixels correspondants aux pixels noirs de la bitmap
#define DRAWBITMAP_XOR  0x02
	//	force au blanc les pixels correspondants aux pixels noirs de la bitmap
#define DRAWBITMAP_NOT  0x03

inline void DrawBitmap(const unsigned char* tuc_Src, int i_SrcWidth, int i_SrcHeight,
    int i_x, int i_y,
    unsigned char* tuc_Dest, int i_DstWidth, int i_DstHeight,
    unsigned char uc_type = DRAWBITMAP_COPY)
{
    DrawBitmapASM(tuc_Src,i_SrcWidth,i_SrcHeight,i_x,i_y,tuc_Dest,i_DstWidth,i_DstHeight,uc_type,0,0);
}

inline void DrawBitmap(const GBitmap* pGBmp_Src,
    int i_x, int i_y,
    GBitmap* pGBmp_Dest,
    unsigned char uc_type = DRAWBITMAP_COPY)
{
    DrawBitmapASM(pGBmp_Src->tuc_Bmp,pGBmp_Src->i_Width,pGBmp_Src->i_Height,i_x,i_y,pGBmp_Dest->tuc_Bmp,pGBmp_Dest->i_Width,pGBmp_Dest->i_Height,uc_type,0,0);
}

			/*** FONCTIONS D'AFFICHAGE D'UNE BITMAP SUR 2 BUFFERS ***/
				/* (2 bitmaps - nuances : 2 buffers ) */

inline void DrawBitmap2(const GBitmap2* pGBmp2_Src,
	int i_x, int i_y,
	GBitmap2* pGBmp2_Dest,
	unsigned char uc_type = DRAWBITMAP_COPY)
{
    DrawBitmapASM(pGBmp2_Src->tuc_Bmp,pGBmp2_Src->i_Width,pGBmp2_Src->i_Height,i_x,i_y,pGBmp2_Dest->tuc_Bmp,pGBmp2_Dest->i_Width,pGBmp2_Dest->i_Height,uc_type,0,0);
    DrawBitmapASM(pGBmp2_Src->tuc_Bmp2,pGBmp2_Src->i_Width,pGBmp2_Src->i_Height,i_x,i_y,pGBmp2_Dest->tuc_Bmp2,pGBmp2_Dest->i_Width,pGBmp2_Dest->i_Height,uc_type,0,0);
}

            /*** FONCTIONS D'AFFICHAGE D'UNE IMAGE DOUBLE ***/
                /* (2 bitmaps - nuances : 1 buffers ) */

	//	Image compos�e:
	//		-	Source 1 : (OR)  pixels correspondants aux pixels noirs et blancs de l'image finale
	//		-	Source 2 : (XOR) pixels correspondants aux pixels blancs et invers�s de l'image finale
#define DRAWIMAGE_ORXOR 0x04
	//	Image compos�e:
	//		-	Source 1 : (NOT) pixels correspondants aux pixels blancs de l'image finale
	//		-	Source 2 : (OR)  pixels correspondants aux pixels noirs de l'image finale
#define DRAWIMAGE_NOTOR 0x05

inline void DrawImage(const unsigned char* tuc_Src1, const unsigned char* tuc_Src2, int i_SrcWidth, int i_SrcHeight,
    int i_x, int i_y,
    unsigned char* tuc_Dest, int i_DstWidth, int i_DstHeight,
    unsigned char uc_type = DRAWIMAGE_ORXOR)
{
    DrawBitmapASM(0,i_SrcWidth,i_SrcHeight,i_x,i_y,tuc_Dest,i_DstWidth,i_DstHeight,uc_type,tuc_Src1,tuc_Src2);
}

inline void DrawImage(const GBitmap* pGBmp_Src1, const GBitmap* pGBmp_Src2,
    int i_x, int i_y,
    const GBitmap* pGBmp_Dest,
    unsigned char uc_type = DRAWIMAGE_ORXOR)
{
    DrawBitmapASM(0,pGBmp_Src1->i_Width,pGBmp_Src1->i_Height,i_x,i_y,pGBmp_Dest->tuc_Bmp,pGBmp_Dest->i_Width,pGBmp_Dest->i_Height,uc_type,pGBmp_Src1->tuc_Bmp,pGBmp_Src2->tuc_Bmp);
}

inline void DrawImage(const GImage* pImg_Src,
    int i_x, int i_y,
    unsigned char* tuc_Dest, int i_DstWidth, int i_DstHeight,
    unsigned char uc_type = DRAWIMAGE_ORXOR)
{
    DrawBitmapASM(0,pImg_Src->i_Width,pImg_Src->i_Height,i_x,i_y,tuc_Dest,i_DstWidth,i_DstHeight,uc_type,pImg_Src->tuc_Bmp_NB,pImg_Src->tuc_Bmp_BI);
}

        /*** FONCTIONS D'AFFICHAGE D'UNE IMAGE DOUBLE SUR 2 BUFFERS ***/
                    /* (3 bitmaps - nuances : 2 buffers ) */

inline void DrawImage2(const unsigned char* tuc_Src_NB, const unsigned char* tuc_Src_BI, const unsigned char* tuc_Src_BI2,
    int i_SrcWidth, int i_SrcHeight,
    int i_x, int i_y,
    unsigned char* tuc_Dest1, unsigned char* tuc_Dest2, int i_DstWidth, int i_DstHeight,
    unsigned char uc_type = DRAWIMAGE_ORXOR)
{
    DrawBitmapASM(0,i_SrcWidth,i_SrcHeight,i_x,i_y,tuc_Dest1,i_DstWidth,i_DstHeight,uc_type,tuc_Src_NB,tuc_Src_BI);
    DrawBitmapASM(0,i_SrcWidth,i_SrcHeight,i_x,i_y,tuc_Dest2,i_DstWidth,i_DstHeight,uc_type,tuc_Src_NB,tuc_Src_BI2);
}

inline void DrawImage2(const GImage2* pImg2_Src,
    int i_x, int i_y,
    unsigned char* tuc_Dest1, unsigned char* tuc_Dest2, int i_DstWidth, int i_DstHeight,
    unsigned char uc_type = DRAWIMAGE_ORXOR)
{
    DrawBitmapASM(0,pImg2_Src->i_Width,pImg2_Src->i_Height,i_x,i_y,tuc_Dest1,i_DstWidth,i_DstHeight,uc_type,pImg2_Src->tuc_Bmp_NB,pImg2_Src->tuc_Bmp_BI);
    DrawBitmapASM(0,pImg2_Src->i_Width,pImg2_Src->i_Height,i_x,i_y,tuc_Dest2,i_DstWidth,i_DstHeight,uc_type,pImg2_Src->tuc_Bmp_NB,pImg2_Src->tuc_Bmp_BI2);
}

};

#endif
