//    This file is part of Gaumerie (C)2006-2007 ClassPad.fr

//    Gaumerie is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.

//    Gaumerie is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Foobar; if not, write to the Free Software
//    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

#ifndef GSTRUCTS_H
#define GSTRUCTS_H

	/*	Librairie "GaumerieLib.lib"
		�crite par Alexandre Rion (gaumerie@hotmail.com)	*/

#ifdef WIN32
#error "These functions only work on Casio ClassPad300"
#endif	/*  WIN32  */
#ifndef __cplusplus
#error "These functions can only be used in C++"
#endif	/*  __cplusplus  */

	/**	STRUCTURES DE BASE POUR LA LIBRAIRIE	**/

//	Fichier(s) Source	:	GPoint.asm
//	Librairie		:	GaumerieLib.lib

namespace GaumerieLib
{
	//	Structure de donn�es de coordonn�es
struct GPoint
{
        	//	coordonn�es
	int i_X;
	int i_Y;

		//	constructeur(s)
	GPoint():
		i_X(0), i_Y(0)
		{	}
	GPoint(int i_cX, int i_cY):
		i_X(i_cX), i_Y(i_cY)
		{	}
	GPoint(const GPoint& GP_c):
		i_X(GP_c.i_X), i_Y(GP_c.i_Y)
		{	}

		//	retourne la somme de deux points
	GPoint operator + (const GPoint&) const;
		//	retourne la diff�rence de deux points
	GPoint operator - (const GPoint&) const;
		//	retourne le produit de deux points
	GPoint operator * (const GPoint&) const;
		//	retourne le quotient de deux points
	GPoint operator / (const GPoint&) const;
		//	retourne le modulo de deux points
	GPoint operator % (const GPoint&) const;

		//	retourne la somme d'un point et un nombre
	GPoint operator + (int) const;
		//	retourne la diff�rence d'un point et un nombre
	GPoint operator - (int) const;
		//	retourne le produit d'un point et un nombre
	GPoint operator * (int) const;
		//	retourne le quotient d'un point et un nombre
	GPoint operator / (int) const;
		//	retourne le modulo d'un point et un nombre
	GPoint operator % (int) const;

		//	additionne un point
	GPoint& operator += (const GPoint&);
		//	soustrait un point
	GPoint& operator -= (const GPoint&);
		//	multiplie par un point
	GPoint& operator *= (const GPoint&);
		//	divise par un point
	GPoint& operator /= (const GPoint&);
		//	prend le modulo avec un point
	GPoint& operator %= (const GPoint&);

		//	additionne un nombre
	GPoint& operator += (int);
		//	soustrait un nombre
	GPoint& operator -= (int);
		//	multiplie par un nombre
	GPoint& operator *= (int);
		//	divise par un nombre
	GPoint& operator /= (int);
		//	prend le modulo par un nombre
	GPoint& operator %= (int);

		//	v�rifie si deux point sont �gaux
	bool operator == (const GPoint&) const;
};
	//	Structure de donn�es de coordonn�es d'un rectangle
struct GRect
{
        	//	coordonn�es
	int i_X1, i_Y1;
	int i_X2, i_Y2;

		//	constructeur(s)
	GRect():
		i_X1(0), i_Y1(0), i_X2(0), i_Y2(0)
		{	}
	GRect(int i_cX1, int i_cY1, int i_cX2, int i_cY2):
		i_X1(i_cX1), i_Y1(i_cY1), i_X2(i_cX2), i_Y2(i_cY2)
		{	}
	GRect(const GPoint& GP_c1, const GPoint& GP_c2):
		i_X1(GP_c1.i_X), i_Y1(GP_c1.i_Y), i_X2(GP_c2.i_X), i_Y2(GP_c2.i_Y)
		{	}
	GRect(const GRect& GR_c):
		i_X1(GR_c.i_X1), i_Y1(GR_c.i_Y1), i_X2(GR_c.i_X2), i_Y2(GR_c.i_Y2)
		{	}

	int Width() const
		{	return i_X2 - i_X1;	}
	int Height() const
		{	return i_Y2 - i_Y1;	}

	GPoint Center() const
		{	return GPoint((i_X1+i_X2)/2,(i_Y1+i_Y2)/2);	}
	GPoint TopLeft() const
		{	return GPoint(i_X1,i_Y1);	}
	GPoint BottomRight() const
		{	return GPoint(i_X2,i_Y2);	}
	GPoint TopRight()
		{	return GPoint(i_X2,i_Y1);	}
	GPoint BottomLeft()
		{	return GPoint(i_X1,i_Y2);	}

	bool Contains(int i_cX, int i_cY) const
		{	return i_X1 <= i_cX && i_cX <= i_X2 && i_Y1 <= i_cY && i_cY <= i_Y2;	}
	bool Contains(const GPoint& GP_c) const
		{	return i_X1 <= GP_c.i_X && GP_c.i_X <= i_X2 && i_Y1 <= GP_c.i_Y && GP_c.i_Y <= i_Y2;	}
    
	bool Overlap(const GRect& GR_c) const
		{
			return !((i_X1 < GR_c.i_X1 && i_X2 < GR_c.i_X1) || (i_X1 > GR_c.i_X2 && i_X2 > GR_c.i_X2) ||
			(i_Y1 < GR_c.i_Y1 && i_Y2 < GR_c.i_Y1) || (i_Y1 > GR_c.i_Y2 && i_Y2 > GR_c.i_Y2));
		}

	GRect& MoveTo(int i_cX, int i_cY)
		{
			i_X2 += i_cX - i_X1;	i_X1 = i_cX;
			i_Y2 += i_cY - i_Y1;	i_Y1 = i_cY;
			return *this;
		}
	GRect& Shift(int i_cDx, int i_cDy)
		{
			i_X1 += i_cDx;	i_X2 += i_cDx;
			i_Y1 += i_cDy;	i_Y2 += i_cDy;
 			return *this;
		}

	GRect operator + (const GPoint& GP_c)
		{
			return GRect(i_X1+GP_c.i_X,i_Y1+GP_c.i_Y,i_X2+GP_c.i_X,i_Y2+GP_c.i_Y);
		}
	GRect operator - (const GPoint& GP_c)
		{
			return GRect(i_X1-GP_c.i_X,i_Y1-GP_c.i_Y,i_X2-GP_c.i_X,i_Y2-GP_c.i_Y);
		}
};
	//	Structure de donn�es d'une bitmap simple
struct GBitmap
{
        	//	dimensions
	int i_Width;
	int i_Height;
		//	addresse de la bitmap
	unsigned char* tuc_Bmp;
};
	//	Structure de donn�es d'une bitmap pour en nuances ( 2 buffers )
struct GBitmap2
{
        	//	dimensions
	int i_Width;
	int i_Height;
		//	addresse des bitmaps
	unsigned char* tuc_Bmp;
	unsigned char* tuc_Bmp2;
};
	//	Structure de donn�es d'une image simple
struct GImage
{
        	//	dimensions
	int i_Width;
	int i_Height;
		//	addresse des bitmaps
	unsigned char* tuc_Bmp_NB;
	unsigned char* tuc_Bmp_BI;
};
	//	Structure de donn�es d'une image en nuances ( buffers )
struct GImage2
{
        	//	dimensions
	int i_Width;
	int i_Height;
		//	addresse des bitmaps
	unsigned char* tuc_Bmp_NB;
	unsigned char* tuc_Bmp_BI;
	unsigned char* tuc_Bmp_BI2;
};

};

#endif /* GSTRUCTS_H */
