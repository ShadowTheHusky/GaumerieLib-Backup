//    This file is part of Gaumerie (C)2006-2007 ClassPad.fr

//    Gaumerie is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.

//    Gaumerie is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.

//    You should have received a copy of the GNU General Public License
//    along with Foobar; if not, write to the Free Software
//    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

#ifndef GAUMERIELIB_H
#define GAUMERIELIB_H

#ifdef WIN32
#error	"Librairie exclusivement utilisable sur Casio ClassPad300"
#endif

//#include "GAUMER~1/HEADER~1/7709S.h"

    /*  Librairie "GaumerieLib.lib"
            �crite par Alexandre Rion (gaumerie@hotmail.com)    */

	//	Headers Files:							//	Sources Files:
#include "GAUMER~1/HEADER~1/DateTime.h"
#include "GAUMER~1/HEADER~1/DrawBitmap.h"	//	DrawBitmap.asm	-  Screen.asm
#include "GAUMER~1/HEADER~1/GetKey.h"		//	GetKey.c
#include "GAUMER~1/HEADER~1/GList.h"		//	GList.asm
#include "GAUMER~1/HEADER~1/GrayScales.h"	//	GrayScales.asm
#include "GAUMER~1/HEADER~1/GString.h"		//	GString.cpp
#include "GAUMER~1/HEADER~1/GStructs.h"		//	GPoint.asm
#include "GAUMER~1/HEADER~1/RTCAlarm.h"		//	RTCAlarm.asm
#include "GAUMER~1/HEADER~1/RTCClock.h"		//	RTCClock.asm
//#include "GAUMER~1/HEADER~1/RTCTimer.h"		//	RTCTimer.asm
#include "GAUMER~1/HEADER~1/SH3Timer.h"		//	SH3Timer.asm
//#include "GAUMER~1/HEADER~1/Timer.h"		//	Timer.cpp - Timer_Clock.asm

using namespace GaumerieLib;

/*
	/!\	Cette librairie met � disposition des fonctions utilisables EXCLUSIVEMENT
		sur Casio ClassPad300, et ne peuvent donc �tre utiliser sur un
		�mulateur sur ordinateur.
*/
/*
	Mode d'emploi pour lier la librairie � un projet:
  -----------------------------------------------------
  		Sous Dev-C++:
  		    - (menu)		"Projet"
  		    - (s�lection)	"Options du projet"	|	(raccourci clavier :	"Alt+P")
			- (onglet)		"Param�tres"
			- Dans la fen�tre "Editeur de liens", ajouter
					-library="GaumerieLib/GaumerieLib.lib"
*/

#endif
